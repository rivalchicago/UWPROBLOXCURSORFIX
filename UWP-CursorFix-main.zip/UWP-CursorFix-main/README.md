# UWP-CursorFix
Updated UWP-CursorFix

# Credits to mengdeveloper
# Updated by funfact

# [+] Automaticly Finding ROBLOX HWND (you dont need to click somewhere)
# [+] New Keybind System


Video : https://streamable.com/g0af0z
